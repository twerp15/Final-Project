public class Main {
    static class Counter {
        private int count;
        private boolean isCountingUp;
        public Counter(boolean isCountingUp) {
            this.isCountingUp = isCountingUp;
            this.count = isCountingUp ? 0 : 20;
        public void increment() {
            if (isCountingUp && count < 20) {
                count++;
                System.out.println("Counting Up: " + count);
            }
        }
        public void decrement() {
            if (!isCountingUp && count > 0) {
                count--;
                System.out.println("Counting Down: " + count);
            }
        }
        public int getCount() {
            return count;
        }
    }
    static class CounterThread extends Thread {
        private Counter counter;
        public CounterThread(Counter counter) {
            this.counter = counter;
        }
        @Override
        public void run() {
            if (counter.isCountingUp) {
                while (counter.getCount() < 20) {
                    counter.increment();
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            } else {
                while (counter.getCount() > 0) {
                    counter.decrement();
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }
    public static void main(String[] args) {
        Counter counterUp = new Counter(true);
        CounterThread threadUp = new CounterThread(counterUp);
        try {
            threadUp.start();
            threadUp.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        Counter counterDown = new Counter(false);
        CounterThread threadDown = new CounterThread(counterDown);

        threadDown.start();
    }
}

